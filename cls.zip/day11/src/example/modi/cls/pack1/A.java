package example.modi.cls.pack1;


/*
 * default(package friendly) 제한자는 접근제한자를 생략하면
 * 자동으로 간주된다. 같은 패키지 내부 자료들끼리만 접근 가능하다.
 */
class A {
	
}
