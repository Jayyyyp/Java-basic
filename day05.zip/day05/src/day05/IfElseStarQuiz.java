package day05;

import java.util.Scanner;

public class IfElseStarQuiz {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		int star = scan.nextInt();
		scan.close();
		for(int i = 1; star <= i; i++) {
			if(i <= star) {
				System.out.print("*");
			}System.out.println();
		}

	}

}
