
public class HelloJava {

	public static void main(String[] args) { // main 치고 ctrl+space
		// sysout 치고 ctrl+space
		System.out.println("Hello World!");
		
	}

}
